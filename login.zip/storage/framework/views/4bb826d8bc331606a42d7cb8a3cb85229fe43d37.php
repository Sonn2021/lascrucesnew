

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto">
        <div class="flex flex-wrap justify-center">
            <div class="w-full max-w-md">

                <h1 class="text-2xl text-gray-700 text-center">You have been successfully logged out</h1>

                <p class='mt-8 text-xl text-indigo-800 text-center underline'><a href="<?php echo e(route('login')); ?>">Login?</a></p>

                <script type="text/javascript">
                    history.pushState(null, null, `<?php echo e(route('logout')); ?>`);
                    window.addEventListener('popstate', function () {
                        history.pushState(null, null, `<?php echo e(route('logout')); ?>`);
                    });
                </script>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\login\resources\views/logout.blade.php ENDPATH**/ ?>