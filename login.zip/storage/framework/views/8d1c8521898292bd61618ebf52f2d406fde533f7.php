<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Selección de comida</title>
</head>


    
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="paso mt-4 justify-content-start">
            <span class="badge bg-brown rounded-circle me-2">2</span>
            <p><b>Selección de comida <?php echo e(Session::get('id')); ?></b></p>
        </div>
        <form action="<?php echo e(route('listacomida.submit')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="tipo" value="2">
            <div class="row row-cols-1 row-cols-md-2 mt-3">
                <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card mb-3 ">
                        <div class="row">
                            <div class="col-6">
                                <img src="<?php echo e(asset($s->imagen)); ?>" class="w-100 h-100" alt="...">
                            </div>
                            <div class="col-6">
                                <div class="card-body overflow-auto">
                                    <p class="id" hidden><?php echo e($s->id); ?></p>
                                    <h5 class="nombre card-title"><?php echo e($s->nombre); ?></h5>
                                    <p class="card-text"><small>$</small><small class="costo text-muted"><?php echo e($s->costo); ?></small></p>
                                    <div class="row">
                                        <?php $__currentLoopData = $horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($h->service_id == $s->id): ?>
                                            <div class="col-sm-6 mb-2">
                                                <?php if(count($horas) > 0): ?>
                                                    <?php if($h->seleccionado == 0): ?>
                                                    <p class="h-id" hidden><?php echo e($h->id); ?></p>
                                                    <input class="form-check-input" type="checkbox" value="<?php echo e($h->id); ?>" name="checkedh[]" id="flexCheckDefault">
                                                    <label class="form-check-label" for="flexCheckDefault">
                                                        <?php echo e($h->hora); ?>

                                                    </label>
                                                    <?php endif; ?>
                                                <?php elseif(count($horas) === 0): ?>
                                                    No hay disponible
                                                <?php endif; ?>
                                            </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php if($s->id > 3): ?>
                                    <input class="form-check-input" type="checkbox" value="<?php echo e($s->id); ?>" name="checked[]" id="flexCheckDefault">
                                    <label class="form-check-label" for="flexCheckDefault">
                                        Agregar
                                    </label>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="w-100 d-flex justify-content-around align-items-center mb-5">
                <button class="btn btn-primary bg-primary"><a href="<?php echo e(action('ReservationController@eliminaComida')); ?>" class="text-light text-decoration-none">ATRÁS</a></button>
                <button type="submit" class="btn btn-primary bg-brown" name="send" value="Submit">CONTINUAR</button>      
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\login\resources\views/seleccionServicios.blade.php ENDPATH**/ ?>