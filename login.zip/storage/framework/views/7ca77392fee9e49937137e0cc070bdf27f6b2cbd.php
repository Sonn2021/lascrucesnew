<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.js"></script>
    <title>Selección de servicios</title>
</head>



<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="mx-auto">
            <h1 class="fw-bolder">Reservación</h1>
        </div>
        <div class="mt-2">
            <div class="formulario mt-3">
                <form action="<?php echo e(route('datos.submit')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="identificador" value="1">
                    <div class="campos">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="floatingInput" name="nombre" placeholder="Juan Perez" required>
                            <label for="floatingInput">Nombre</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="floatingInput" name="correo" placeholder="Correo electrónico" required>
                            <label for="floatingInput">Correo electrónico</label>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="exampleFormControlInput1" class="form-label">No. personas</label>
                                <input class="quantity form-control" min="0" max="100"  value="1" name="personas" type="number" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Día</label>
                                <!--<input placeholder="Select date" type="date" id="dia" class="form-control" name="dia">-->
                                <input id="date_picker" type="date" class="form-control" name="dia" required>
                            </div>
                            <div class="col-md-4">
                                <label for="exampleFormControlInput1" class="form-label">Hora</label>
                                <input type="time" id="inputMDEx1" class="form-control" name="hora" required>
                            </div>
                        </div>
                        <!--<button type="button" class="btn bg-brown boton mt-5 m-auto">CONTINUAR</button>-->
                        <div class="form-check mt-3">
                            <input class="form-check-input" type="checkbox" value="" id="recibir">
                            <label class="form-check-label" for="flexCheckDefault">
                                Acepto recibir la información de mi pedido por correo electrónico
                            </label>
                        </div>
                    </div>
                    <div class="w-100 d-flex justify-content-center align-items-center mt-5">
                        <button type="submit" class="btn btn-primary bg-brown" name="send" value="Submit" id="continuar" disabled>CONTINUAR</button>      
                    </div>          
                </form>
            </div>
        </div>
    </div>

    <script language="javascript">
        var today = new Date();
        var dd = String(today.getDate() + 2).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0');
        var yyyy = today.getFullYear();

        today = yyyy + '-' + mm + '-' + dd;
        $('#date_picker').attr('min',today);
    </script>

    <script>
        $(document).ready(function(){
            $("#recibir").click(function(){
                $("#continuar").prop( "disabled", !this.checked );
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\login\resources\views/datosReservacion.blade.php ENDPATH**/ ?>