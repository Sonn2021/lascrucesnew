<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Selección de comida</title>
</head>


    
<?php $__env->startSection('content'); ?>
    <div class="container" id="general">
        <div class="paso mt-4 justify-content-start mb-5">
            <span class="badge bg-brown rounded-circle me-2">4</span>
            <p><b> Orden  </b></p>
        </div>
        <div class="w-100">
            <?php if($message = Session::get('error')): ?>
                <div id="successMessage" class="alert alert-danger alert-block">
                    <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>
        </div>
        <form action="<?php echo e(route('actualizar.cantidad')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <table class="seleccionados table" id="productos">
                <thead>
                    <tr>
                        <th>Nombre del producto</th>
                        <th>Precio</th>
                        <th>Cantidad</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody class="lista-productos">
                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->id_reservation == Session::get('id')): ?>
                        <tr>
                            <td><?php echo e($p->food->nombre); ?> </td>
                            <td class="p-costo"><?php echo e($p->food->costo); ?></td>
                            <td>
                                <input type="hidden" name="id1[]" value="<?php echo e($p->id); ?>">
                                <button type="button" class="buttonmenos btn btn-primary btn-sm">-</button>
                                <input type='number' id='cantidad' name='checked1[]' min='1' max='20' value='<?php echo e($p->cantidad); ?>' class="border-0 text-center" readonly>
                                <button type="button" class="buttonmas btn btn-primary btn-sm">+</button>
                            </td>
                            <td class="p-total"><?php echo e($p->food->costo); ?></td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($s->id_reservation == Session::get('id')): ?>
                        <tr>
                            <td><?php echo e($s->services->nombre); ?> <?php if($s->horario != "N/A"): ?><strong><?php echo e($s->horario); ?></strong><?php endif; ?></td>
                            <td class="p-costo"><?php echo e($s->services->costo); ?></td>
                            <td>
                                <input type="hidden" name="id2[]" value="<?php echo e($s->id); ?>">
                                <?php if($s->horario == "N/A"): ?>
                                    <button type="button" class="buttonmenos btn btn-primary btn-sm">-</button>
                                    <input type='number' id='cantidad' name='checked2[]' min='1' max='20' value='<?php echo e($s->cantidad); ?>' class="border-0 text-center" readonly>
                                    <button type="button" class="buttonmas btn btn-primary btn-sm">+</button>
                                <?php endif; ?>
                            </td>
                            <td class="p-total"><?php echo e($s->services->costo); ?></td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="total">
                <p class="d-none"><?php echo e($reservacion->total); ?></p>
                <h4><b> Total: </b><input type="text" class="cantidad-total border-0" name="total" value="0" readonly></h4>
            </div>
            <div class="w-100 d-flex justify-content-around align-items-center mb-5">
                <button class="btn btn-primary bg-primary"><a href="<?php echo e(action('ReservationController@eliminaServicios')); ?>" class="text-light text-decoration-none">ATRÁS</a></button> 
                <button type="submit" class="btn btn-primary bg-brown" name="send" value="Submit">CONTINUAR</button>      
            </div>
        </form>
    </div>

    <script>
        $(document).ready(function(){

            setTimeout(function() {$('#successMessage').fadeOut('fast');}, 3000);

            var producto = "";
            var nombre = "";
            var costo = "";
            var total = 0;
            var cantidad = 0;
            var id = "";
            var id_hora = "N";
            var hora = "";
            var total_pedido = 0;
            var aux = 0;

            aux = $(".d-none").text();
            //alert(aux);

            $('.p-costo').each(function(){
                total_pedido += parseFloat($(this).text());  
            });

            if(aux==0){
                $('input[name=total]').val(total_pedido);
            }else{
                $('input[name=total]').val(aux);
                total_pedido = parseInt(aux);
            }
            
            //Agregar elemento al carrito de compras
            $(".seleccionados").on("click","input[type=number]", function(){
                costo = $(this).closest("tr").find(".p-costo").text();
                cantidad = $(this).val();
                $(this).closest("tr").find(".p-total").html(costo*cantidad);

                total_pedido += parseInt(costo);
                $('input[name=total]').val(total_pedido);
            });

            $("#general").on("click","button.buttonmas",function(){
                costo = $(this).closest("tr").find(".p-costo").text();
                x = $(this).closest("tr").find("input[type=number]").val();
                x++;
                $(this).closest("tr").find("input[type=number]").val(x);

                $(this).closest("tr").find(".p-total").text(parseInt(costo*x));
                total_pedido += parseInt(costo);
                $('input[name=total]').val(total_pedido);
            });

            $("#general").on("click","button.buttonmenos",function(){
                x = $(this).closest("tr").find("input[type=number]").val();
                if(x>1){
                    costo = $(this).closest("tr").find(".p-costo").text();
                    x--;
                    $(this).closest("tr").find("input[type=number]").val(x);
                    $(this).closest("tr").find(".p-total").text(parseInt(costo*x));
                    total_pedido -= parseInt(costo);
                    $('input[name=total]').val(total_pedido);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\login\resources\views/orden.blade.php ENDPATH**/ ?>