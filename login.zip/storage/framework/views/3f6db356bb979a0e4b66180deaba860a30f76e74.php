<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Reservaciones realizadas</title>
</head>


    
<?php $__env->startSection('content'); ?>
    <div class="container" id="general">
        <div class="paso mt-4 justify-content-start mb-3">
            <h4 class="fw-bolder">Reservaciones</h4>
        </div>
        <div class="row row-cols-1 row-cols-md-1 g-4">
            <?php $__currentLoopData = $reservaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <p class="card-title"><strong>Nombre: </strong><?php echo e($s->nombre); ?></p>
                            <p><strong>Telefono:</strong> <?php echo e($s->correo); ?></p>
                            <p class="card-text"><strong>No. personas:</strong> <?php echo e($s->personas); ?></p>
                            <p><strong>Dia:</strong> <?php echo e($s->dia); ?></p>
                            <p><strong>Hora:</strong> <?php echo e($s->hora); ?></p>
                            <p><strong>Productos</strong></p>
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($p->id_reservation == $s->id): ?>
                                    <div class="row wh-100">
                                        <div class="col-10">
                                            <p><?php echo e($p->food->nombre); ?></p>
                                        </div>
                                        <div class="col-2">
                                            <p><?php echo e($p->cantidad); ?></p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p><strong>Servicios</strong></p>
                            <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $se): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($se->id_reservation == $s->id): ?>
                                    <div class="row wh-100">
                                        <div class="col-10">
                                            <p><?php echo e($se->services->nombre); ?> <?php if($se->horario != "N/A"): ?><strong><?php echo e($se->horario); ?></strong><?php endif; ?></p>
                                        </div>
                                        <div class="col-2">
                                            <p><?php echo e($se->cantidad); ?></p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\login\resources\views/reservacionesRealizadas.blade.php ENDPATH**/ ?>