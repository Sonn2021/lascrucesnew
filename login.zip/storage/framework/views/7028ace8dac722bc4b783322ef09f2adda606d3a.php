<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Selección de comida</title>
</head>


    
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="paso mt-4 justify-content-start">
            <span class="badge bg-brown rounded-circle me-2">2</span>
            <p><b>Selección de comida <?php echo e(Session::get('id')); ?></b></p>
        </div>
        <form action="<?php echo e(route('listacomida.submit')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="tipo" value="1">
            <div class="row row-cols-1 row-cols-md-2 mt-3">
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card mb-3 ">
                        <div class="row">
                            <div class="col-6">
                                <img src="<?php echo e(asset($p->imagen)); ?>" class="w-100 h-100" alt="...">
                            </div>
                            <div class="col-6">
                                <div class="card-body">
                                    <p class="id" hidden><?php echo e($p->id); ?></p>
                                    <h5 class="nombre card-title"><?php echo e($p->nombre); ?></h5>
                                    <!--<p class="descripcion card-text"><?php echo e($p->descripcion); ?></p>-->
                                    <p class="card-text"><small>$</small><small class="costo text-muted"><?php echo e($p->costo); ?></small></p>
                                    <input class="form-check-input" type="checkbox" value="<?php echo e($p->id); ?>" name="checked[]" id="flexCheckDefault">
                                    <label class="form-check-label" for="flexCheckDefault">
                                        Agregar
                                    </label>
                                    <!--<button type="button" class="agregar <?php echo e($p->id); ?> btn btn-primary btn-sm">AGREGAR</button>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="w-100 d-flex justify-content-center align-items-center mb-5">
                <button type="submit" class="btn btn-primary bg-brown" name="send" value="Submit">CONTINUAR</button>      
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\login\resources\views/seleccionComida.blade.php ENDPATH**/ ?>