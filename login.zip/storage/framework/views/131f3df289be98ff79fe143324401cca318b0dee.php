<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <link rel="stylesheet" href="css/estilos.css">
    <title>Nombre</title>
</head>
<body>
    <div class="container mt-5 mb-5" style="background-color: blue">
            <div class="card p-5 d-flex justify-content-center aling-items-center">
                <div>
                    <h1>Información de la reservación</h1>
                    <p>Id de la reservación: <?php echo e($id); ?></p>
                    <p>Nombre: <?php echo e($nombre); ?></p>
                    <p>Número de personas: <?php echo e($personas); ?></p>
                    <p>Día de la visita: <?php echo e($dia); ?></p>
                    <p>Hora de la visita: <?php echo e($hora); ?></p>
                    <p>Total a pagar: <?php echo e($total); ?></p>
                    <p>Comida seleccionada:</p>
                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($p->food->nombre); ?>: <?php echo e($p->cantidad); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <p>Servicios seleccionado(s):</p>
                    <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($s->services->nombre); ?> : <?php echo e($s->cantidad); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <img src="img/logo.png" alt="" class="w-25 mx-auto"> 
            </div>
        </div>
</body>
</html><?php /**PATH C:\laragon\www\login\resources\views/emails/reservationmail.blade.php ENDPATH**/ ?>