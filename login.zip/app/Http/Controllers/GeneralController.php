<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GeneralController extends Controller
{
    public function index()
    {
        return view('index');
    }

    public function galeria()
    {
        return view('galeria');
    }

    public function recomendaciones_y_compromisos()
    {
        return view('recomendaciones_y_compromisos');
    }

    public function FAQ()
    {
        return view('FAQ');
    }

    public function acerca_de()
    {
        return view('acerca_de');
    }
}
